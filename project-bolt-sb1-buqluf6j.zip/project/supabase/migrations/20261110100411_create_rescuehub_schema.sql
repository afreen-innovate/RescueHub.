/*
# RescueHub core schema: incidents and response teams

Plain English: creates the two tables the emergency platform needs. Incidents hold every emergency report, and teams hold the response teams that can be sent to them.

1. New Tables
- `teams`: response teams with name, team code, response category (Fire, Medical, Rescue, Police), location, availability (Available or Busy) and the incident they are assigned to.
- `incidents`: emergency reports with public Report ID, title, description, category, severity, people affected, status, address, live coordinates, contact details, SOS flag and assigned team.

2. Modified Tables
- None.

3. Security
- Row Level Security is enabled on both tables.
- The `anon` and `authenticated` roles can read, create, update and delete rows. The demo has no user login and the data is intentionally shared.
- Table access is granted only to those two roles.

4. Important Notes
- 1. `report_id` is unique so each public Report ID points to exactly one incident.
- 2. Foreign keys link incidents to teams and teams to incidents. Deleting one side clears the link instead of deleting the other record.
- 3. Statements are idempotent so the migration can be safely re-applied.
*/

CREATE TABLE IF NOT EXISTS teams (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  team_code text NOT NULL,
  category text NOT NULL CHECK (category IN ('Fire', 'Medical', 'Rescue', 'Police')),
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  availability text NOT NULL DEFAULT 'Available' CHECK (availability IN ('Available', 'Busy')),
  assigned_incident_id uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS incidents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id text NOT NULL UNIQUE,
  title text NOT NULL,
  description text,
  category text NOT NULL CHECK (category IN ('Fire Emergency', 'Road Accident', 'Medical Emergency', 'Flood', 'Building Collapse', 'Other Emergencies')),
  severity text NOT NULL CHECK (severity IN ('Low', 'Medium', 'High', 'Critical')),
  people_affected integer NOT NULL DEFAULT 1 CHECK (people_affected >= 0),
  status text NOT NULL DEFAULT 'Reported' CHECK (status IN ('Reported', 'Pending', 'Assigned', 'In Progress', 'Resolved')),
  address text,
  latitude double precision,
  longitude double precision,
  location_updated_at timestamptz,
  contact text,
  is_sos boolean NOT NULL DEFAULT false,
  assigned_team_id uuid REFERENCES teams(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'teams_assigned_incident_fk') THEN
    ALTER TABLE teams ADD CONSTRAINT teams_assigned_incident_fk
      FOREIGN KEY (assigned_incident_id) REFERENCES incidents(id) ON DELETE SET NULL;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS incidents_status_idx ON incidents (status);
CREATE INDEX IF NOT EXISTS incidents_category_idx ON incidents (category);
CREATE INDEX IF NOT EXISTS incidents_assigned_team_idx ON incidents (assigned_team_id);
CREATE INDEX IF NOT EXISTS teams_assigned_incident_idx ON teams (assigned_incident_id);

ALTER TABLE incidents ENABLE ROW LEVEL SECURITY;
ALTER TABLE teams ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON incidents TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON teams TO anon, authenticated;

DROP POLICY IF EXISTS "anon_select_incidents" ON incidents;
CREATE POLICY "anon_select_incidents" ON incidents FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_incidents" ON incidents;
CREATE POLICY "anon_insert_incidents" ON incidents FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_incidents" ON incidents;
CREATE POLICY "anon_update_incidents" ON incidents FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_incidents" ON incidents;
CREATE POLICY "anon_delete_incidents" ON incidents FOR DELETE TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_teams" ON teams;
CREATE POLICY "anon_select_teams" ON teams FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_teams" ON teams;
CREATE POLICY "anon_insert_teams" ON teams FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_teams" ON teams;
CREATE POLICY "anon_update_teams" ON teams FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_teams" ON teams;
CREATE POLICY "anon_delete_teams" ON teams FOR DELETE TO anon, authenticated USING (true);
