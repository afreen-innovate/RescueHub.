# Project memory

## Product intent & audience

- Emergency coordination web app for incident reporting, resource management, live tracking, and admin oversight
- Audience: emergency responders, dispatchers/coordinators, and administrators
- Core features: incident reporting, resource management, live tracking (Leaflet maps), admin dashboard

## Brand personality & voice

- Authoritative, clear, and action-oriented — conveys urgency without panic
- Professional emergency-services tone; prioritizes clarity and status communication

## Visual design & UX direction

- Map-centric UI (Leaflet) as primary navigation/monitoring surface
- Status-driven visual language: active/resolved/critical states with distinct color coding
- High contrast and legibility prioritized for high-stress, fast-reading contexts
- Dashboard layout with data summaries, incident lists, and resource panels
- Tailwind CSS for styling; lucide-react for all icons
- Responsive design needed for both command-center desktops and field mobile use
- Accessibility critical: clear contrast, readable typography, keyboard-navigable controls

## Decisions, constraints & rationale

- Stack: Vite + React + Tailwind + Leaflet (no extra UI/icon packages unless necessary)
- Path alias `@/` → `src/` for all project imports
- Data layer: database connection details are currently unconfirmed — pages may show "Could not load" errors until configured
- App is feature-complete; deployment via Bolt Publish flow

## Open questions & assumptions

- Database/backend connection not yet verified — may need configuration fix
- Real-time update mechanism unspecified (polling vs. WebSocket) — assumed basic for now
- Role definitions and auth flow not yet detailed (admin vs. responder vs. reporter)
- Data persistence approach unclear — needs confirmation
- Map data sources and tile providers not yet specified