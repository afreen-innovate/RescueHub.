import { SEVERITIES, type Category, type Incident, type Severity, type TeamCategory } from './types';

const BASE_SEVERITY: Record<Category, Severity> = {
  'Fire Emergency': 'High',
  'Building Collapse': 'High',
  'Medical Emergency': 'High',
  Flood: 'Medium',
  'Road Accident': 'Medium',
  'Other Emergencies': 'Low',
};

const SEVERITY_POINTS: Record<Severity, number> = { Low: 10, Medium: 25, High: 40, Critical: 55 };

const CATEGORY_POINTS: Record<Category, number> = {
  'Fire Emergency': 10,
  'Building Collapse': 10,
  'Medical Emergency': 9,
  Flood: 7,
  'Road Accident': 6,
  'Other Emergencies': 3,
};

const SUITABLE_TEAM: Record<Category, TeamCategory> = {
  'Fire Emergency': 'Fire',
  'Medical Emergency': 'Medical',
  'Road Accident': 'Medical',
  Flood: 'Rescue',
  'Building Collapse': 'Rescue',
  'Other Emergencies': 'Rescue',
};

export const AVERAGE_SPEED_KMH = 40;

export function computeSeverity(category: Category, peopleAffected: number, isSos = false): Severity {
  if (isSos) return 'Critical';
  let level = SEVERITIES.indexOf(BASE_SEVERITY[category]);
  if (peopleAffected >= 6) level += 1;
  if (peopleAffected >= 20) level += 1;
  return SEVERITIES[Math.min(level, SEVERITIES.length - 1)];
}

export function minutesSince(iso: string, now: number): number {
  return Math.max(0, (now - new Date(iso).getTime()) / 60000);
}

export function formatElapsed(iso: string, now: number): string {
  const minutes = Math.floor(minutesSince(iso, now));
  if (minutes < 1) return 'Just now';
  if (minutes < 60) return `${minutes} min ago`;
  return `${Math.floor(minutes / 60)} h ${minutes % 60} min ago`;
}

export function priorityScore(incident: Incident, now: number): number {
  const score =
    SEVERITY_POINTS[incident.severity] +
    Math.min(incident.people_affected, 20) * 1.5 +
    Math.min(minutesSince(incident.created_at, now), 60) * 0.25 +
    CATEGORY_POINTS[incident.category];
  return Math.round(score * 10) / 10;
}

export type PriorityLevel = 'Critical' | 'High' | 'Medium' | 'Low';

export function priorityLevel(score: number): PriorityLevel {
  if (score >= 80) return 'Critical';
  if (score >= 55) return 'High';
  if (score >= 35) return 'Medium';
  return 'Low';
}

export function suitableTeamCategory(category: Category): TeamCategory {
  return SUITABLE_TEAM[category];
}

export function haversineKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function etaMinutes(distanceKm: number): number {
  return Math.round((distanceKm / AVERAGE_SPEED_KMH) * 60);
}

export function isOpen(incident: Incident): boolean {
  return incident.status !== 'Resolved';
}
