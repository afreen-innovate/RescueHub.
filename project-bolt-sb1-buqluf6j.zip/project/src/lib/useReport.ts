import { useEffect, useRef, useState } from 'react';
import { findIncidentByReportId, findTeamById } from './api';
import type { Incident, Team } from './types';

export function useReport(
  reportId: string | null,
  afterLoad?: (incident: Incident) => Promise<void> | void,
  intervalMs = 5000,
) {
  const [incident, setIncident] = useState<Incident | null>(null);
  const [team, setTeam] = useState<Team | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const afterLoadRef = useRef(afterLoad);

  useEffect(() => {
    afterLoadRef.current = afterLoad;
  });

  useEffect(() => {
    if (!reportId) return;
    let cancelled = false;
    const load = async () => {
      setLoading(true);
      try {
        const found = await findIncidentByReportId(reportId);
        if (cancelled) return;
        setNotFound(!found);
        setIncident(found);
        const assigned = found?.assigned_team_id ? await findTeamById(found.assigned_team_id) : null;
        if (cancelled) return;
        setTeam(assigned);
        if (found) await afterLoadRef.current?.(found);
        setError(null);
      } catch (err) {
        if (!cancelled) setError(err instanceof Error ? err.message : 'Could not load this report.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    load();
    const timer = window.setInterval(load, intervalMs);
    return () => {
      cancelled = true;
      window.clearInterval(timer);
    };
  }, [reportId, intervalMs]);

  return { incident, team, notFound, error, loading: loading && !incident };
}
