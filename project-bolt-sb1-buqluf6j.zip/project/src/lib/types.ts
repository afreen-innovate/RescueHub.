export const CATEGORIES = [
  'Fire Emergency',
  'Road Accident',
  'Medical Emergency',
  'Flood',
  'Building Collapse',
  'Other Emergencies',
] as const;
export type Category = (typeof CATEGORIES)[number];

export const SEVERITIES = ['Low', 'Medium', 'High', 'Critical'] as const;
export type Severity = (typeof SEVERITIES)[number];

export const STATUSES = ['Reported', 'Pending', 'Assigned', 'In Progress', 'Resolved'] as const;
export type Status = (typeof STATUSES)[number];

export const TEAM_CATEGORIES = ['Fire', 'Medical', 'Rescue', 'Police'] as const;
export type TeamCategory = (typeof TEAM_CATEGORIES)[number];

export const AVAILABILITIES = ['Available', 'Busy'] as const;
export type Availability = (typeof AVAILABILITIES)[number];

export interface Incident {
  id: string;
  report_id: string;
  title: string;
  description: string | null;
  category: Category;
  severity: Severity;
  people_affected: number;
  status: Status;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
  location_updated_at: string | null;
  contact: string | null;
  is_sos: boolean;
  assigned_team_id: string | null;
  created_at: string;
  updated_at: string;
}

export type NewIncident = Pick<
  Incident,
  | 'title'
  | 'description'
  | 'category'
  | 'severity'
  | 'people_affected'
  | 'address'
  | 'latitude'
  | 'longitude'
  | 'location_updated_at'
  | 'contact'
  | 'is_sos'
>;

export interface Team {
  id: string;
  name: string;
  team_code: string;
  category: TeamCategory;
  latitude: number;
  longitude: number;
  availability: Availability;
  assigned_incident_id: string | null;
  created_at: string;
}

export type NewTeam = Pick<Team, 'name' | 'team_code' | 'category' | 'latitude' | 'longitude' | 'availability'>;
