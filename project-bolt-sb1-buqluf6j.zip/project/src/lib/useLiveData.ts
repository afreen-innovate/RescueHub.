import { useCallback, useEffect, useState } from 'react';
import { fetchIncidents, fetchTeams, seedIfEmpty } from './api';
import type { Incident, Team } from './types';

const REFRESH_MS = 3000;

export function useLiveData() {
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [now, setNow] = useState(() => Date.now());

  const load = useCallback(async () => {
    try {
      await seedIfEmpty();
      const [nextIncidents, nextTeams] = await Promise.all([fetchIncidents(), fetchTeams()]);
      setIncidents(nextIncidents);
      setTeams(nextTeams);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not load data.');
    } finally {
      setLoading(false);
      setNow(Date.now());
    }
  }, []);

  useEffect(() => {
    load();
    const timer = window.setInterval(load, REFRESH_MS);
    return () => window.clearInterval(timer);
  }, [load]);

  return { incidents, teams, loading, error, now, reload: load };
}
