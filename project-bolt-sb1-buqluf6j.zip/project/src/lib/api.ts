import { supabase } from './supabase';
import { SEED_INCIDENTS, SEED_TEAMS } from './seed';
import { computeSeverity } from './logic';
import type { Incident, NewIncident, NewTeam, Status, Team } from './types';

interface QueryResult<T> {
  data: T | null;
  error: { message: string; code?: string } | null;
}

function unwrap<T>(res: QueryResult<T>): T {
  if (res.error) throw new Error(res.error.message);
  return res.data as T;
}

const REPORT_ID_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';

function randomReportId(): string {
  let id = 'RH-';
  for (let i = 0; i < 6; i++) {
    id += REPORT_ID_CHARS[Math.floor(Math.random() * REPORT_ID_CHARS.length)];
  }
  return id;
}

export async function fetchIncidents(): Promise<Incident[]> {
  return unwrap(await supabase.from('incidents').select('*').order('created_at', { ascending: false })) as Incident[];
}

export async function fetchTeams(): Promise<Team[]> {
  return unwrap(await supabase.from('teams').select('*').order('name')) as Team[];
}

export async function findTeamById(id: string): Promise<Team | null> {
  return unwrap(await supabase.from('teams').select('*').eq('id', id).maybeSingle()) as Team | null;
}

export async function findIncidentByReportId(reportId: string): Promise<Incident | null> {
  return unwrap(
    await supabase.from('incidents').select('*').eq('report_id', reportId).maybeSingle(),
  ) as Incident | null;
}

export async function createIncident(input: NewIncident): Promise<Incident> {
  for (let attempt = 0; attempt < 5; attempt++) {
    const reportId = randomReportId();
    const existing = await supabase.from('incidents').select('id').eq('report_id', reportId).maybeSingle();
    if (unwrap(existing) !== null) continue;
    const inserted = await supabase.from('incidents').insert({ ...input, report_id: reportId }).select().single();
    if (inserted.error?.code === '23505') continue;
    return unwrap(inserted) as Incident;
  }
  throw new Error('Could not create a unique Report ID. Please try again.');
}

export async function updateIncidentLocation(id: string, latitude: number, longitude: number): Promise<void> {
  unwrap(
    await supabase
      .from('incidents')
      .update({ latitude, longitude, location_updated_at: new Date().toISOString() })
      .eq('id', id)
      .select('id')
      .single(),
  );
}

export async function setIncidentStatus(id: string, status: Status): Promise<void> {
  unwrap(
    await supabase
      .from('incidents')
      .update({ status, updated_at: new Date().toISOString() })
      .eq('id', id)
      .select('id')
      .single(),
  );
}

export async function setIncidentSeverity(id: string, severity: Incident['severity']): Promise<void> {
  unwrap(await supabase.from('incidents').update({ severity }).eq('id', id).select('id').single());
}

export async function releaseTeam(teamId: string): Promise<void> {
  unwrap(
    await supabase
      .from('teams')
      .update({ availability: 'Available', assigned_incident_id: null })
      .eq('id', teamId)
      .select('id')
      .single(),
  );
}

export async function assignTeam(incident: Incident, team: Team): Promise<void> {
  if (incident.assigned_team_id && incident.assigned_team_id !== team.id) {
    await releaseTeam(incident.assigned_team_id);
  }
  unwrap(
    await supabase
      .from('teams')
      .update({ availability: 'Busy', assigned_incident_id: incident.id })
      .eq('id', team.id)
      .select('id')
      .single(),
  );
  unwrap(
    await supabase
      .from('incidents')
      .update({ assigned_team_id: team.id, status: 'Assigned', updated_at: new Date().toISOString() })
      .eq('id', incident.id)
      .select('id')
      .single(),
  );
}

export async function resolveIncident(incident: Incident): Promise<void> {
  if (incident.assigned_team_id) await releaseTeam(incident.assigned_team_id);
  await setIncidentStatus(incident.id, 'Resolved');
}

export async function deleteIncident(incident: Incident): Promise<void> {
  if (incident.assigned_team_id) await releaseTeam(incident.assigned_team_id);
  unwrap(await supabase.from('incidents').delete().eq('id', incident.id).select('id'));
}

export async function createTeam(input: NewTeam): Promise<Team> {
  return unwrap(await supabase.from('teams').insert(input).select('*').single()) as Team;
}

export async function updateTeam(
  team: Team,
  input: NewTeam,
  assignedIncidentId: string | null,
  incidents: Incident[],
): Promise<void> {
  const previous = team.assigned_incident_id;
  const busy = assignedIncidentId !== null;
  unwrap(
    await supabase
      .from('teams')
      .update({ ...input, availability: busy ? 'Busy' : input.availability, assigned_incident_id: assignedIncidentId })
      .eq('id', team.id)
      .select('id')
      .single(),
  );
  if (previous && previous !== assignedIncidentId) {
    const old = incidents.find((i) => i.id === previous);
    if (old && old.assigned_team_id === team.id) {
      unwrap(
        await supabase
          .from('incidents')
          .update({ assigned_team_id: null, status: 'Pending' })
          .eq('id', previous)
          .select('id')
          .single(),
      );
    }
  }
  if (assignedIncidentId) {
    unwrap(
      await supabase
        .from('incidents')
        .update({ assigned_team_id: team.id, status: 'Assigned', updated_at: new Date().toISOString() })
        .eq('id', assignedIncidentId)
        .select('id')
        .single(),
    );
  }
}

export async function deleteTeam(team: Team, incidents: Incident[]): Promise<void> {
  const linked = incidents.find((i) => i.assigned_team_id === team.id);
  if (linked) {
    unwrap(
      await supabase
        .from('incidents')
        .update({ assigned_team_id: null, status: 'Pending' })
        .eq('id', linked.id)
        .select('id')
        .single(),
    );
  }
  unwrap(await supabase.from('teams').delete().eq('id', team.id).select('id'));
}

let seeding: Promise<void> | null = null;

async function seedDatabase(): Promise<void> {
  const teamCount = await supabase.from('teams').select('id', { count: 'exact', head: true });
  if (teamCount.error) throw new Error(teamCount.error.message);
  if (!teamCount.count) {
    unwrap(await supabase.from('teams').insert(SEED_TEAMS).select('id'));
  }

  const incidentCount = await supabase.from('incidents').select('id', { count: 'exact', head: true });
  if (incidentCount.error) throw new Error(incidentCount.error.message);
  if (incidentCount.count) return;

  const teams = unwrap(await supabase.from('teams').select('*')) as Team[];
  const now = Date.now();
  const rows = SEED_INCIDENTS.map(({ assignTo, minutesAgo, ...seed }) => ({
    ...seed,
    severity: computeSeverity(seed.category, seed.people_affected, seed.is_sos),
    created_at: new Date(now - minutesAgo * 60000).toISOString(),
    assigned_team_id: assignTo ? (teams.find((t) => t.team_code === assignTo)?.id ?? null) : null,
  }));
  const incidents = unwrap(await supabase.from('incidents').insert(rows).select('*')) as Incident[];

  for (const incident of incidents) {
    if (!incident.assigned_team_id || incident.status === 'Resolved') continue;
    unwrap(
      await supabase
        .from('teams')
        .update({ availability: 'Busy', assigned_incident_id: incident.id })
        .eq('id', incident.assigned_team_id)
        .select('id')
        .single(),
    );
  }
}

export function seedIfEmpty(): Promise<void> {
  seeding ??= seedDatabase().catch((error) => {
    seeding = null;
    throw error;
  });
  return seeding;
}
