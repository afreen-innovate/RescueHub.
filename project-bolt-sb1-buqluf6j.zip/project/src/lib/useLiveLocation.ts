import { useEffect, useState } from 'react';

export type LocationStatus = 'off' | 'locating' | 'live' | 'denied' | 'unavailable';

export interface Coords {
  lat: number;
  lng: number;
}

const SLOW_FIX_MS = 5000;

export function useLiveLocation(enabled: boolean) {
  const [status, setStatus] = useState<LocationStatus>('off');
  const [coords, setCoords] = useState<Coords | null>(null);
  const [updatedAt, setUpdatedAt] = useState<number | null>(null);
  const [slow, setSlow] = useState(false);

  useEffect(() => {
    if (!enabled) {
      setStatus('off');
      setSlow(false);
      return;
    }
    if (!navigator.geolocation) {
      setStatus('unavailable');
      return;
    }
    setStatus('locating');
    setSlow(false);
    const slowTimer = window.setTimeout(() => setSlow(true), SLOW_FIX_MS);
    const watchId = navigator.geolocation.watchPosition(
      (position) => {
        window.clearTimeout(slowTimer);
        setSlow(false);
        setCoords({ lat: position.coords.latitude, lng: position.coords.longitude });
        setUpdatedAt(Date.now());
        setStatus('live');
      },
      (error) => {
        window.clearTimeout(slowTimer);
        setStatus(error.code === error.PERMISSION_DENIED ? 'denied' : 'unavailable');
      },
      { enableHighAccuracy: true, maximumAge: 2000 },
    );
    return () => {
      window.clearTimeout(slowTimer);
      navigator.geolocation.clearWatch(watchId);
    };
  }, [enabled]);

  return { status, coords, updatedAt, slow };
}

export function getCurrentCoords(timeoutMs = 5000): Promise<Coords | null> {
  return new Promise((resolve) => {
    if (!navigator.geolocation) {
      resolve(null);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (position) => resolve({ lat: position.coords.latitude, lng: position.coords.longitude }),
      () => resolve(null),
      { enableHighAccuracy: true, timeout: timeoutMs, maximumAge: 10000 },
    );
  });
}
