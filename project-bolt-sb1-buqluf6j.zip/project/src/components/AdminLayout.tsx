import { useState, type FormEvent, type ReactNode } from 'react';
import { LayoutDashboard, Lock, LogOut, ShieldAlert, Siren, Truck, Users } from 'lucide-react';
import { Link, navigate } from '@/lib/router';

const ADMIN_PASSWORD = 'rescue2026';
const SESSION_KEY = 'rescuehub-admin';

const NAV = [
  { to: '/admin', label: 'Emergency Dashboard', icon: LayoutDashboard },
  { to: '/admin/incidents', label: 'Incident Management', icon: Siren },
  { to: '/admin/teams', label: 'Response Teams', icon: Users },
];

function AdminLogin({ onSuccess }: { onSuccess: () => void }) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (password !== ADMIN_PASSWORD) {
      setError('Incorrect password. Please try again.');
      return;
    }
    sessionStorage.setItem(SESSION_KEY, '1');
    onSuccess();
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-950 p-4 text-slate-100">
      <form onSubmit={submit} className="w-full max-w-sm space-y-5 rounded-2xl border border-slate-800 bg-slate-900 p-8 shadow-2xl">
        <div className="flex flex-col items-center gap-3 text-center">
          <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-red-600 text-white">
            <ShieldAlert size={28} strokeWidth={2.5} />
          </span>
          <div>
            <h1 className="text-xl font-bold">RescueHub Command</h1>
            <p className="text-sm text-slate-400">Enter the responder password to continue</p>
          </div>
        </div>
        <label className="block space-y-2">
          <span className="text-sm font-medium text-slate-300">Password</span>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoFocus
            className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3 text-slate-100 outline-none transition focus:border-red-500 focus:ring-2 focus:ring-red-500/30"
          />
        </label>
        {error && <p className="text-sm text-red-400">{error}</p>}
        <button type="submit" className="flex w-full items-center justify-center gap-2 rounded-xl bg-red-600 py-3 font-semibold text-white transition hover:bg-red-500">
          <Lock size={16} /> Unlock Command Center
        </button>
      </form>
    </div>
  );
}

export default function AdminLayout({ active, children }: { active: string; children: ReactNode }) {
  const [authed, setAuthed] = useState(() => sessionStorage.getItem(SESSION_KEY) === '1');

  if (!authed) return <AdminLogin onSuccess={() => setAuthed(true)} />;

  const logout = () => {
    sessionStorage.removeItem(SESSION_KEY);
    setAuthed(false);
    navigate('/admin');
  };

  return (
    <div className="flex min-h-screen bg-slate-950 text-slate-100">
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-r border-slate-800 bg-slate-900 p-5 md:flex">
        <div className="mb-8 flex items-center gap-2 text-lg font-bold">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-red-600">
            <ShieldAlert size={20} strokeWidth={2.5} />
          </span>
          RescueHub
        </div>
        <nav className="flex-1 space-y-1">
          {NAV.map(({ to, label, icon: Icon }) => (
            <Link
              key={to}
              to={to}
              className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition ${
                active === to ? 'bg-red-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-slate-100'
              }`}
            >
              <Icon size={18} />
              {label}
            </Link>
          ))}
        </nav>
        <Link to="/" className="mb-3 rounded-xl px-3 py-2 text-sm text-slate-400 transition hover:text-slate-100">
          Back to public site
        </Link>
        <button onClick={logout} className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm font-medium text-slate-400 transition hover:bg-slate-800 hover:text-slate-100">
          <LogOut size={18} /> Log out
        </button>
      </aside>
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex items-center justify-between border-b border-slate-800 bg-slate-950/95 px-4 py-3 backdrop-blur md:hidden">
          <span className="flex items-center gap-2 font-bold">
            <Truck size={18} className="text-red-500" /> RescueHub
          </span>
          <nav className="flex gap-1 text-sm">
            {NAV.map(({ to, label }) => (
              <Link key={to} to={to} className={`rounded-lg px-2.5 py-1.5 ${active === to ? 'bg-red-600 text-white' : 'text-slate-400'}`}>
                {label.split(' ')[0]}
              </Link>
            ))}
          </nav>
        </header>
        <main className="min-w-0 flex-1 p-4 sm:p-6 lg:p-8">{children}</main>
      </div>
    </div>
  );
}
