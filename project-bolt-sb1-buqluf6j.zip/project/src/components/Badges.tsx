import type { Availability, Severity, Status } from '@/lib/types';
import type { PriorityLevel } from '@/lib/logic';
import { STATUSES } from '@/lib/types';
import { Check } from 'lucide-react';

const SEVERITY_STYLES: Record<Severity, string> = {
  Low: 'bg-emerald-100 text-emerald-800 ring-emerald-200',
  Medium: 'bg-amber-100 text-amber-800 ring-amber-200',
  High: 'bg-orange-100 text-orange-800 ring-orange-200',
  Critical: 'bg-red-600 text-white ring-red-700',
};

const PRIORITY_STYLES: Record<PriorityLevel, string> = {
  Low: 'bg-slate-500/20 text-slate-300 ring-slate-500/40',
  Medium: 'bg-amber-500/20 text-amber-300 ring-amber-500/40',
  High: 'bg-orange-500/20 text-orange-300 ring-orange-500/40',
  Critical: 'bg-red-500/25 text-red-300 ring-red-500/50',
};

const STATUS_STYLES: Record<Status, string> = {
  Reported: 'bg-slate-100 text-slate-700 ring-slate-200',
  Pending: 'bg-amber-100 text-amber-800 ring-amber-200',
  Assigned: 'bg-sky-100 text-sky-800 ring-sky-200',
  'In Progress': 'bg-blue-100 text-blue-800 ring-blue-200',
  Resolved: 'bg-emerald-100 text-emerald-800 ring-emerald-200',
};

const pill = 'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ring-inset whitespace-nowrap';

export function SeverityBadge({ severity }: { severity: Severity }) {
  return <span className={`${pill} ${SEVERITY_STYLES[severity]}`}>{severity}</span>;
}

export function PriorityBadge({ level }: { level: PriorityLevel }) {
  return <span className={`${pill} ${PRIORITY_STYLES[level]}`}>{level}</span>;
}

export function StatusBadge({ status }: { status: Status }) {
  return <span className={`${pill} ${STATUS_STYLES[status]}`}>{status}</span>;
}

export function AvailabilityBadge({ availability }: { availability: Availability }) {
  const style =
    availability === 'Available'
      ? 'bg-emerald-500/20 text-emerald-300 ring-emerald-500/40'
      : 'bg-slate-500/20 text-slate-300 ring-slate-500/40';
  return <span className={`${pill} ${style}`}>{availability}</span>;
}

export function StatusTimeline({ status }: { status: Status }) {
  const current = STATUSES.indexOf(status);
  return (
    <ol className="space-y-0">
      {STATUSES.map((step, index) => {
        const done = index <= current;
        const isLast = index === STATUSES.length - 1;
        return (
          <li key={step} className="flex gap-4">
            <div className="flex flex-col items-center">
              <div
                className={`flex h-8 w-8 items-center justify-center rounded-full border-2 transition-colors ${
                  done ? 'border-red-600 bg-red-600 text-white' : 'border-slate-300 bg-white text-slate-400'
                }`}
              >
                {done ? <Check size={16} strokeWidth={3} /> : <span className="text-xs font-bold">{index + 1}</span>}
              </div>
              {!isLast && <div className={`w-0.5 flex-1 min-h-6 ${index < current ? 'bg-red-600' : 'bg-slate-200'}`} />}
            </div>
            <div className="pb-6">
              <p className={`font-semibold ${done ? 'text-slate-900' : 'text-slate-400'}`}>{step}</p>
              {index === current && <p className="text-sm text-red-600">Current status</p>}
            </div>
          </li>
        );
      })}
    </ol>
  );
}
