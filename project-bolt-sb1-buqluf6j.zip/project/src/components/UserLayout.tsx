import type { ReactNode } from 'react';
import { ShieldAlert } from 'lucide-react';
import { Link } from '@/lib/router';

export default function UserLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col">
      <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-4 sm:px-6">
          <Link to="/" className="flex items-center gap-2 text-lg font-extrabold tracking-tight">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-red-600 text-white">
              <ShieldAlert size={20} strokeWidth={2.5} />
            </span>
            RescueHub
          </Link>
          <nav className="flex items-center gap-1 sm:gap-2">
            <Link to="/track" className="rounded-xl px-3 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-100">
              Track My Report
            </Link>
            <Link to="/report" className="rounded-xl bg-red-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-red-700">
              Report Emergency
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex-1">{children}</main>
      <footer className="border-t border-slate-200 py-6 text-center text-sm text-slate-500">
        <Link to="/admin" className="font-medium text-slate-600 underline-offset-4 hover:text-red-600 hover:underline">
          Responder login
        </Link>
      </footer>
    </div>
  );
}
