import { Truck } from 'lucide-react';
import type { Incident, Team } from '@/lib/types';
import { etaMinutes, haversineKm } from '@/lib/logic';
import { AvailabilityBadge } from '@/components/Badges';

export default function AssignedTeamCard({ team, incident }: { team: Team | null; incident: Incident }) {
  if (!team) {
    return (
      <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-5 text-center">
        <p className="font-semibold text-slate-700">Waiting for a response team</p>
        <p className="mt-1 text-sm text-slate-500">A team will be assigned as soon as one is available.</p>
      </div>
    );
  }

  const hasDistance = incident.latitude !== null && incident.longitude !== null;
  const distance = hasDistance
    ? haversineKm(team.latitude, team.longitude, incident.latitude as number, incident.longitude as number)
    : null;

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="flex items-start gap-4">
        <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-red-600 text-white">
          <Truck size={24} />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium text-slate-500">Assigned team</p>
          <p className="text-lg font-bold text-slate-900">{team.name}</p>
          <p className="text-sm text-slate-600">
            {team.team_code} · {team.category} response
          </p>
        </div>
        <AvailabilityBadge availability={team.availability} />
      </div>
      {distance !== null && (
        <div className="mt-5 grid grid-cols-2 gap-3">
          <div className="rounded-xl bg-slate-50 p-3">
            <p className="text-xs font-medium uppercase tracking-wide text-slate-500">Distance</p>
            <p className="text-xl font-bold text-slate-900">{distance.toFixed(1)} km</p>
          </div>
          <div className="rounded-xl bg-red-50 p-3">
            <p className="text-xs font-medium uppercase tracking-wide text-red-700">Estimated arrival</p>
            <p className="text-xl font-bold text-red-700">About {etaMinutes(distance)} min</p>
          </div>
        </div>
      )}
    </div>
  );
}
