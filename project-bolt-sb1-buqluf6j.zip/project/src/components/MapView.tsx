import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

export interface MapMarker {
  id: string;
  lat: number;
  lng: number;
  color: string;
  label: string;
  square?: boolean;
}

interface MapViewProps {
  markers: MapMarker[];
  route?: [number, number][];
  onPick?: (lat: number, lng: number) => void;
  className?: string;
  center?: [number, number];
}

const DEFAULT_CENTER: [number, number] = [13.08, 80.27];

function pinIcon(marker: MapMarker) {
  const shape = marker.square ? 'rounded-md' : 'rounded-full';
  return L.divIcon({
    className: '',
    iconSize: [28, 28],
    iconAnchor: [14, 14],
    html: `<div class="${shape} border-[3px] border-white shadow-lg" style="width:28px;height:28px;background:${marker.color}"></div>`,
  });
}

export default function MapView({ markers, route, onPick, className = 'h-80', center = DEFAULT_CENTER }: MapViewProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const layerRef = useRef<L.LayerGroup | null>(null);
  const pickRef = useRef(onPick);
  const fittedRef = useRef(false);

  useEffect(() => {
    pickRef.current = onPick;
  });

  useEffect(() => {
    if (!containerRef.current) return;
    const map = L.map(containerRef.current, { center, zoom: 12, zoomControl: true });
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap contributors',
    }).addTo(map);
    layerRef.current = L.layerGroup().addTo(map);
    map.on('click', (event: L.LeafletMouseEvent) => pickRef.current?.(event.latlng.lat, event.latlng.lng));
    mapRef.current = map;
    const resizeTimer = window.setTimeout(() => map.invalidateSize(), 100);
    return () => {
      window.clearTimeout(resizeTimer);
      map.remove();
      mapRef.current = null;
      layerRef.current = null;
      fittedRef.current = false;
    };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    const layer = layerRef.current;
    if (!map || !layer) return;
    layer.clearLayers();
    markers.forEach((marker) => {
      L.marker([marker.lat, marker.lng], { icon: pinIcon(marker), title: marker.label })
        .bindTooltip(marker.label)
        .addTo(layer);
    });
    if (route && route.length === 2) {
      L.polyline(route, { color: '#dc2626', weight: 4, dashArray: '8 10' }).addTo(layer);
    }
    if (!fittedRef.current && markers.length > 0) {
      const bounds = L.latLngBounds(markers.map((m) => [m.lat, m.lng] as [number, number]));
      map.fitBounds(bounds.pad(0.2), { maxZoom: 14 });
      fittedRef.current = true;
    }
  }, [markers, route]);

  return <div ref={containerRef} className={`w-full rounded-2xl overflow-hidden z-0 ${className}`} />;
}
