import { useState, type FormEvent } from 'react';
import { LocateFixed, X } from 'lucide-react';
import MapView from '@/components/MapView';
import { createTeam, updateTeam } from '@/lib/api';
import { getCurrentCoords } from '@/lib/useLiveLocation';
import { AVAILABILITIES, TEAM_CATEGORIES, type Availability, type Incident, type NewTeam, type Team, type TeamCategory } from '@/lib/types';

interface TeamFormProps {
  team: Team | null;
  incidents: Incident[];
  onClose: () => void;
  onSaved: () => void;
}

const DEFAULT_CENTER: [number, number] = [13.08, 80.27];

export default function TeamForm({ team, incidents, onClose, onSaved }: TeamFormProps) {
  const [name, setName] = useState(team?.name ?? '');
  const [code, setCode] = useState(team?.team_code ?? '');
  const [category, setCategory] = useState<TeamCategory>(team?.category ?? 'Rescue');
  const [availability, setAvailability] = useState<Availability>(team?.availability ?? 'Available');
  const [assignedId, setAssignedId] = useState<string>(team?.assigned_incident_id ?? '');
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(
    team ? { lat: team.latitude, lng: team.longitude } : null,
  );
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const assignable = incidents.filter((i) => i.status !== 'Resolved' || i.id === team?.assigned_incident_id);

  const useMyLocation = async () => {
    const found = await getCurrentCoords(5000);
    if (found) setCoords(found);
    else setError('Your location is not available. Tap the map to set the location.');
  };

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (!name.trim() || !code.trim()) {
      setError('Team name and team ID are required.');
      return;
    }
    if (!coords) {
      setError('Tap the map or use your location to set the team position.');
      return;
    }
    const input: NewTeam = {
      name: name.trim(),
      team_code: code.trim().toUpperCase(),
      category,
      latitude: coords.lat,
      longitude: coords.lng,
      availability,
    };
    setSaving(true);
    setError(null);
    try {
      if (team) {
        await updateTeam(team, input, assignedId || null, incidents);
      } else {
        const created = await createTeam(input);
        if (assignedId) await updateTeam(created, input, assignedId, incidents);
      }
      onSaved();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'The team could not be saved.');
      setSaving(false);
    }
  };

  const inputClass = 'w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-slate-100 outline-none focus:border-red-500';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-black/70 p-4 backdrop-blur-sm">
      <form onSubmit={submit} className="w-full max-w-2xl space-y-5 rounded-2xl border border-slate-800 bg-slate-900 p-6 shadow-2xl">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold">{team ? 'Edit Response Team' : 'Add Response Team'}</h2>
          <button type="button" onClick={onClose} aria-label="Close" className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-slate-100">
            <X size={20} />
          </button>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <label className="space-y-1.5">
            <span className="text-sm text-slate-400">Team name</span>
            <input value={name} onChange={(e) => setName(e.target.value)} className={inputClass} maxLength={80} />
          </label>
          <label className="space-y-1.5">
            <span className="text-sm text-slate-400">Team ID</span>
            <input value={code} onChange={(e) => setCode(e.target.value)} className={`${inputClass} font-mono uppercase`} maxLength={20} />
          </label>
          <label className="space-y-1.5">
            <span className="text-sm text-slate-400">Response category</span>
            <select value={category} onChange={(e) => setCategory(e.target.value as TeamCategory)} className={inputClass}>
              {TEAM_CATEGORIES.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </label>
          <label className="space-y-1.5">
            <span className="text-sm text-slate-400">Availability status</span>
            <select value={availability} onChange={(e) => setAvailability(e.target.value as Availability)} className={inputClass}>
              {AVAILABILITIES.map((a) => (
                <option key={a} value={a}>{a}</option>
              ))}
            </select>
          </label>
          <label className="space-y-1.5 sm:col-span-2">
            <span className="text-sm text-slate-400">Assigned incident</span>
            <select value={assignedId} onChange={(e) => setAssignedId(e.target.value)} className={inputClass}>
              <option value="">None</option>
              {assignable.map((i) => (
                <option key={i.id} value={i.id}>{i.report_id} · {i.title}</option>
              ))}
            </select>
          </label>
        </div>

        <div className="space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <span className="text-sm text-slate-400">Current location (tap the map or use my location)</span>
            <button
              type="button"
              onClick={useMyLocation}
              className="flex items-center gap-2 rounded-lg bg-slate-800 px-3 py-1.5 text-sm font-semibold text-slate-100 transition hover:bg-slate-700"
            >
              <LocateFixed size={16} /> Use my location
            </button>
          </div>
          <MapView
            className="h-64"
            center={coords ? [coords.lat, coords.lng] : DEFAULT_CENTER}
            markers={coords ? [{ id: 'team', lat: coords.lat, lng: coords.lng, color: '#2563eb', label: name || 'Team location', square: true }] : []}
            onPick={(lat, lng) => setCoords({ lat, lng })}
          />
          <p className="font-mono text-xs text-slate-500">
            {coords ? `${coords.lat.toFixed(4)}, ${coords.lng.toFixed(4)}` : 'No location set yet'}
          </p>
        </div>

        {error && <p className="rounded-xl border border-red-900 bg-red-950/40 p-3 text-sm text-red-300">{error}</p>}

        <div className="flex justify-end gap-3">
          <button type="button" onClick={onClose} className="rounded-xl px-5 py-2.5 font-semibold text-slate-300 hover:bg-slate-800">
            Cancel
          </button>
          <button type="submit" disabled={saving} className="rounded-xl bg-red-600 px-5 py-2.5 font-bold text-white transition hover:bg-red-500 disabled:opacity-60">
            {saving ? 'Saving...' : team ? 'Save Changes' : 'Create Team'}
          </button>
        </div>
      </form>
    </div>
  );
}
