import { useEffect } from 'react';
import { seedIfEmpty } from '@/lib/api';
import AdminLayout from '@/components/AdminLayout';
import UserLayout from '@/components/UserLayout';
import { Link, usePath } from '@/lib/router';
import HomePage from '@/pages/HomePage';
import ReportPage from '@/pages/ReportPage';
import LiveReportPage from '@/pages/LiveReportPage';
import TrackPage from '@/pages/TrackPage';
import DashboardPage from '@/pages/admin/DashboardPage';
import IncidentsPage from '@/pages/admin/IncidentsPage';
import IncidentDetailPage from '@/pages/admin/IncidentDetailPage';
import TeamsPage from '@/pages/admin/TeamsPage';

function NotFound() {
  return (
    <UserLayout>
      <div className="mx-auto max-w-md px-4 py-24 text-center">
        <p className="text-2xl font-bold">Page not found</p>
        <Link to="/" className="mt-4 inline-block rounded-xl bg-red-600 px-5 py-3 font-semibold text-white hover:bg-red-700">
          Back to home
        </Link>
      </div>
    </UserLayout>
  );
}

function renderAdmin(section: string | undefined, id: string | undefined) {
  if (!section) return <DashboardPage />;
  if (section === 'incidents') return id ? <IncidentDetailPage incidentId={decodeURIComponent(id)} /> : <IncidentsPage />;
  if (section === 'teams') return <TeamsPage />;
  return null;
}

export default function App() {
  const path = usePath();
  const [pathname, query = ''] = path.split('?');
  const [root, second, third] = pathname.split('/').filter(Boolean);

  useEffect(() => {
    seedIfEmpty().catch(() => undefined);
  }, []);

  if (root === 'admin') {
    const page = renderAdmin(second, third);
    if (!page) return <NotFound />;
    return <AdminLayout active={second ? `/admin/${second}` : '/admin'}>{page}</AdminLayout>;
  }
  if (!root) return <HomePage />;
  if (root === 'report') {
    return second ? <LiveReportPage reportId={decodeURIComponent(second).toUpperCase()} /> : <ReportPage />;
  }
  if (root === 'track') {
    return <TrackPage reportId={new URLSearchParams(query).get('id')?.trim().toUpperCase() || null} />;
  }
  return <NotFound />;
}
