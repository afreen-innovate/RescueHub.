import { useState } from 'react';
import { ClipboardList, Search, ShieldCheck, Siren, MapPin, Clock } from 'lucide-react';
import UserLayout from '@/components/UserLayout';
import { createIncident } from '@/lib/api';
import { getCurrentCoords } from '@/lib/useLiveLocation';
import { computeSeverity } from '@/lib/logic';
import { Link, navigate } from '@/lib/router';

const STEPS = [
  { icon: MapPin, title: 'Live location shared', text: 'Responders see exactly where you are.' },
  { icon: ShieldCheck, title: 'Nearest team alerted', text: 'The closest suitable team is sent.' },
  { icon: Clock, title: 'Track anytime', text: 'Use your Report ID to follow progress.' },
];

export default function HomePage() {
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const sendSos = async () => {
    if (sending) return;
    setSending(true);
    setError(null);
    try {
      const coords = await getCurrentCoords(5000);
      const incident = await createIncident({
        title: 'SOS Emergency',
        description: 'SOS sent from the home screen.',
        category: 'Other Emergencies',
        severity: computeSeverity('Other Emergencies', 1, true),
        people_affected: 1,
        address: null,
        latitude: coords?.lat ?? null,
        longitude: coords?.lng ?? null,
        location_updated_at: coords ? new Date().toISOString() : null,
        contact: null,
        is_sos: true,
      });
      navigate(`/report/${incident.report_id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'SOS could not be sent. Please try again.');
      setSending(false);
    }
  };

  return (
    <UserLayout>
      <section className="mx-auto flex max-w-3xl flex-col items-center px-4 pb-12 pt-10 text-center sm:pt-16">
        <p className="mb-3 inline-flex items-center gap-2 rounded-full bg-red-50 px-4 py-1.5 text-sm font-semibold text-red-700">
          <span className="h-2 w-2 animate-pulse rounded-full bg-red-600" /> Emergency response is online
        </p>
        <h1 className="text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl">
          Help is one tap away
        </h1>
        <p className="mt-4 max-w-xl text-lg leading-relaxed text-slate-600">
          Report an emergency in seconds. Your live location goes straight to the nearest response team.
        </p>

        <div className="relative mt-12 flex h-64 w-64 items-center justify-center">
          <span className="absolute inset-0 animate-ping rounded-full bg-red-500/30" />
          <span className="absolute inset-4 rounded-full bg-red-500/15" />
          <button
            type="button"
            onClick={sendSos}
            disabled={sending}
            aria-label="Send SOS alert"
            className="relative flex h-56 w-56 flex-col items-center justify-center rounded-full bg-red-600 text-white shadow-2xl shadow-red-600/40 ring-8 ring-red-100 transition duration-200 hover:scale-105 hover:bg-red-700 active:scale-95 disabled:cursor-wait disabled:opacity-80"
          >
            <Siren size={44} strokeWidth={2.5} />
            <span className="mt-2 text-5xl font-black tracking-wider">{sending ? '...' : 'SOS'}</span>
            <span className="mt-1 text-sm font-medium text-red-100">{sending ? 'Sending alert' : 'Tap for instant help'}</span>
          </button>
        </div>
        {error && <p className="mt-6 rounded-xl bg-red-50 px-4 py-3 text-sm font-medium text-red-700">{error}</p>}

        <div className="mt-12 grid w-full gap-4 sm:grid-cols-2">
          <Link
            to="/report"
            className="flex items-center justify-center gap-3 rounded-2xl bg-red-600 px-6 py-6 text-xl font-bold text-white shadow-lg shadow-red-600/20 transition hover:-translate-y-0.5 hover:bg-red-700 active:translate-y-0"
          >
            <ClipboardList size={28} /> Report Emergency
          </Link>
          <Link
            to="/track"
            className="flex items-center justify-center gap-3 rounded-2xl border-2 border-slate-900 bg-white px-6 py-6 text-xl font-bold text-slate-900 transition hover:-translate-y-0.5 hover:bg-slate-900 hover:text-white active:translate-y-0"
          >
            <Search size={28} /> Track My Report
          </Link>
        </div>
      </section>

      <section className="border-t border-slate-200 bg-slate-50">
        <div className="mx-auto grid max-w-5xl gap-6 px-4 py-12 sm:grid-cols-3 sm:px-6">
          {STEPS.map(({ icon: Icon, title, text }) => (
            <div key={title} className="flex items-start gap-4 rounded-2xl bg-white p-5 shadow-sm">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-red-50 text-red-600">
                <Icon size={22} />
              </span>
              <div>
                <p className="font-bold text-slate-900">{title}</p>
                <p className="mt-1 text-sm leading-relaxed text-slate-600">{text}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </UserLayout>
  );
}
