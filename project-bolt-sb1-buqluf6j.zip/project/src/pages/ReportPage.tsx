import { useState, type FormEvent } from 'react';
import { Building2, Car, CircleAlert, Flame, HeartPulse, LocateFixed, Minus, Plus, Radio, Waves, type LucideIcon } from 'lucide-react';
import UserLayout from '@/components/UserLayout';
import MapView from '@/components/MapView';
import { createIncident } from '@/lib/api';
import { CATEGORIES, type Category } from '@/lib/types';
import { computeSeverity } from '@/lib/logic';
import { navigate } from '@/lib/router';
import { useLiveLocation, type Coords, type LocationStatus } from '@/lib/useLiveLocation';

const CATEGORY_ICONS: Record<Category, LucideIcon> = {
  'Fire Emergency': Flame,
  'Road Accident': Car,
  'Medical Emergency': HeartPulse,
  Flood: Waves,
  'Building Collapse': Building2,
  'Other Emergencies': CircleAlert,
};

const DESCRIPTION_CHIPS = ['Trapped', 'Fire spreading', 'Need ambulance'];
const PEOPLE_PRESETS = [1, 5, 10, 20];
const MAX_PEOPLE = 999;

export default function ReportPage() {
  const [category, setCategory] = useState<Category | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [address, setAddress] = useState('');
  const [contact, setContact] = useState('');
  const [people, setPeople] = useState(1);
  const [sharing, setSharing] = useState(false);
  const [pinned, setPinned] = useState<Coords | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const live = useLiveLocation(sharing);

  const activeCoords = pinned ?? (sharing ? live.coords : null);
  const showMap = live.status === 'denied' || live.status === 'unavailable' || (sharing && live.slow && !activeCoords);

  const chooseCategory = (next: Category) => {
    setCategory(next);
    setTitle(next);
  };

  const addChip = (chip: string) => {
    setDescription((current) => (current.trim() ? `${current.trim()}. ${chip}` : chip));
  };

  const setPeopleCount = (value: number) => {
    setPeople(Math.min(MAX_PEOPLE, Math.max(1, Math.round(value) || 1)));
  };

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (!category) {
      setError('Please choose an emergency category.');
      return;
    }
    if (!title.trim()) {
      setError('Please enter an incident title.');
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      const incident = await createIncident({
        title: title.trim(),
        description: description.trim() || null,
        category,
        severity: computeSeverity(category, people),
        people_affected: people,
        address: address.trim() || null,
        latitude: activeCoords?.lat ?? null,
        longitude: activeCoords?.lng ?? null,
        location_updated_at: activeCoords ? new Date().toISOString() : null,
        contact: contact.trim() || null,
        is_sos: false,
      });
      navigate(`/report/${incident.report_id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'The report could not be sent. Please try again.');
      setSubmitting(false);
    }
  };

  const inputClass =
    'w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-base text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-red-600 focus:ring-4 focus:ring-red-100';

  return (
    <UserLayout>
      <form onSubmit={submit} className="mx-auto max-w-2xl space-y-8 px-4 py-8 sm:px-6 sm:py-10">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">Report an emergency</h1>
          <p className="mt-2 text-slate-600">Fill in as much as you can. Only the category is required.</p>
        </div>

        <section className="space-y-3">
          <h2 className="text-lg font-bold">1. Emergency category</h2>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
            {CATEGORIES.map((item) => {
              const Icon = CATEGORY_ICONS[item];
              const selected = category === item;
              return (
                <button
                  key={item}
                  type="button"
                  onClick={() => chooseCategory(item)}
                  aria-pressed={selected}
                  className={`flex flex-col items-center gap-3 rounded-2xl border-2 p-5 text-center transition duration-200 hover:-translate-y-0.5 ${
                    selected ? 'border-red-600 bg-red-50 shadow-md shadow-red-600/10' : 'border-slate-200 bg-white hover:border-red-300'
                  }`}
                >
                  <span className={`flex h-14 w-14 items-center justify-center rounded-2xl ${selected ? 'bg-red-600 text-white' : 'bg-slate-100 text-slate-700'}`}>
                    <Icon size={28} />
                  </span>
                  <span className="text-sm font-bold leading-tight text-slate-900">{item}</span>
                </button>
              );
            })}
          </div>
        </section>

        <section className="space-y-3">
          <h2 className="text-lg font-bold">2. Incident title</h2>
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Choose a category above or type a title"
            maxLength={120}
            className={inputClass}
          />
        </section>

        <section className="space-y-3">
          <h2 className="text-lg font-bold">3. Description <span className="font-normal text-slate-500">(optional)</span></h2>
          <div className="flex flex-wrap gap-2">
            {DESCRIPTION_CHIPS.map((chip) => (
              <button
                key={chip}
                type="button"
                onClick={() => addChip(chip)}
                className="rounded-full border border-red-200 bg-red-50 px-4 py-2 text-sm font-semibold text-red-700 transition hover:bg-red-600 hover:text-white"
              >
                + {chip}
              </button>
            ))}
          </div>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
            placeholder="What is happening?"
            className={inputClass}
          />
        </section>

        <section className="space-y-4">
          <h2 className="text-lg font-bold">4. Location</h2>
          <input
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder="Address or nearest landmark"
            className={inputClass}
          />
          <button
            type="button"
            onClick={() => setSharing((on) => !on)}
            className={`flex w-full items-center justify-center gap-2 rounded-xl px-4 py-3.5 text-base font-bold transition ${
              sharing ? 'bg-emerald-600 text-white hover:bg-emerald-700' : 'bg-slate-900 text-white hover:bg-slate-800'
            }`}
          >
            <LocateFixed size={20} />
            {sharing ? 'Stop Sharing Live Location' : 'Share Live Location'}
          </button>
          <LocationStatusNote sharing={sharing} status={live.status} hasCoords={activeCoords !== null} pinned={pinned !== null} />
          {showMap && (
            <div className="space-y-2">
              <p className="text-sm font-semibold text-red-700">Tap the map to set the incident location.</p>
              <MapView
                className="h-64"
                markers={activeCoords ? [{ id: 'incident', lat: activeCoords.lat, lng: activeCoords.lng, color: '#dc2626', label: 'Incident location', square: true }] : []}
                onPick={(lat, lng) => setPinned({ lat, lng })}
              />
            </div>
          )}
        </section>

        <section className="space-y-3">
          <h2 className="text-lg font-bold">5. People affected</h2>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setPeopleCount(people - 1)}
              aria-label="Decrease people affected"
              className="flex h-14 w-14 items-center justify-center rounded-xl border-2 border-slate-300 bg-white transition hover:border-red-600 hover:text-red-600 active:scale-95"
            >
              <Minus size={24} />
            </button>
            <input
              type="number"
              min={1}
              max={MAX_PEOPLE}
              value={people}
              onChange={(e) => setPeopleCount(Number(e.target.value))}
              className="h-14 w-24 rounded-xl border-2 border-slate-300 text-center text-2xl font-bold outline-none focus:border-red-600"
            />
            <button
              type="button"
              onClick={() => setPeopleCount(people + 1)}
              aria-label="Increase people affected"
              className="flex h-14 w-14 items-center justify-center rounded-xl border-2 border-slate-300 bg-white transition hover:border-red-600 hover:text-red-600 active:scale-95"
            >
              <Plus size={24} />
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {PEOPLE_PRESETS.map((value) => (
              <button
                key={value}
                type="button"
                onClick={() => setPeopleCount(value)}
                className={`rounded-xl px-5 py-2.5 text-base font-bold transition ${
                  people === value ? 'bg-red-600 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {value}
              </button>
            ))}
          </div>
        </section>

        <section className="space-y-3">
          <h2 className="text-lg font-bold">6. Contact information <span className="font-normal text-slate-500">(optional)</span></h2>
          <input
            value={contact}
            onChange={(e) => setContact(e.target.value)}
            placeholder="Phone number or email"
            className={inputClass}
          />
        </section>

        {error && <p className="rounded-xl bg-red-50 px-4 py-3 text-sm font-medium text-red-700">{error}</p>}

        <button
          type="submit"
          disabled={submitting}
          className="w-full rounded-2xl bg-red-600 py-5 text-xl font-black tracking-wide text-white shadow-xl shadow-red-600/30 transition hover:bg-red-700 active:scale-[0.99] disabled:cursor-wait disabled:opacity-70"
        >
          {submitting ? 'Sending report...' : 'Submit Emergency Report'}
        </button>
      </form>
    </UserLayout>
  );
}

function LocationStatusNote({
  sharing,
  status,
  hasCoords,
  pinned,
}: {
  sharing: boolean;
  status: LocationStatus;
  hasCoords: boolean;
  pinned: boolean;
}) {
  if (pinned) {
    return <p className="flex items-center gap-2 text-sm font-medium text-emerald-700"><Radio size={16} /> Location pinned on the map.</p>;
  }
  if (!sharing) {
    return <p className="text-sm text-slate-500">Optional. You can also type an address above.</p>;
  }
  if (status === 'live' && hasCoords) {
    return <p className="flex items-center gap-2 text-sm font-medium text-emerald-700"><Radio size={16} /> Live location found. It keeps updating while this page is open.</p>;
  }
  if (status === 'denied') {
    return <p className="text-sm font-medium text-red-700">Location access is blocked. You can still submit and tap the map.</p>;
  }
  if (status === 'unavailable') {
    return <p className="text-sm font-medium text-red-700">Location is not available on this device. You can still submit.</p>;
  }
  return <p className="text-sm text-slate-600">Finding your location...</p>;
}
