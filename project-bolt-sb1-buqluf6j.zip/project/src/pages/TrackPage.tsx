import { useState, type FormEvent } from 'react';
import { Search } from 'lucide-react';
import UserLayout from '@/components/UserLayout';
import AssignedTeamCard from '@/components/AssignedTeamCard';
import { SeverityBadge, StatusBadge, StatusTimeline } from '@/components/Badges';
import { navigate } from '@/lib/router';
import { useReport } from '@/lib/useReport';

export default function TrackPage({ reportId }: { reportId: string | null }) {
  const [input, setInput] = useState(reportId ?? '');
  const [formError, setFormError] = useState<string | null>(null);
  const { incident, team, notFound, error, loading } = useReport(reportId);

  const submit = (event: FormEvent) => {
    event.preventDefault();
    const id = input.trim().toUpperCase();
    if (!id) {
      setFormError('Please enter your Report ID.');
      return;
    }
    setFormError(null);
    navigate(`/track?id=${encodeURIComponent(id)}`);
  };

  return (
    <UserLayout>
      <div className="mx-auto max-w-2xl space-y-6 px-4 py-8 sm:px-6 sm:py-10">
        <div className="text-center">
          <h1 className="text-3xl font-extrabold tracking-tight">Track My Report</h1>
          <p className="mt-2 text-slate-600">Enter the Report ID you received when you submitted your emergency.</p>
        </div>

        <form onSubmit={submit} className="flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:flex-row sm:p-5">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="RH-XXXXXX"
            aria-label="Report ID"
            autoCapitalize="characters"
            className="w-full rounded-xl border border-slate-300 px-4 py-3.5 font-mono text-lg font-bold uppercase tracking-widest text-slate-900 outline-none transition placeholder:font-sans placeholder:text-base placeholder:font-normal placeholder:tracking-normal placeholder:text-slate-400 focus:border-red-600 focus:ring-4 focus:ring-red-100"
          />
          <button
            type="submit"
            className="flex shrink-0 items-center justify-center gap-2 rounded-xl bg-red-600 px-6 py-3.5 text-base font-bold text-white transition hover:bg-red-700 active:scale-[0.98]"
          >
            <Search size={20} /> Track
          </button>
        </form>
        {formError && <p className="text-sm font-medium text-red-700">{formError}</p>}

        {reportId && loading && !incident && <p className="text-center text-slate-600">Searching for your report...</p>}
        {reportId && notFound && (
          <div className="rounded-2xl border border-slate-200 p-8 text-center">
            <p className="text-lg font-bold">No report found for {reportId}</p>
            <p className="mt-2 text-slate-600">Check the ID on your confirmation screen and try again.</p>
          </div>
        )}
        {reportId && error && !incident && <p className="text-center text-sm font-medium text-red-700">{error}</p>}

        {incident && (
          <div className="space-y-6">
            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="font-mono text-sm font-bold tracking-widest text-red-600">{incident.report_id}</p>
                  <h2 className="text-xl font-bold break-words">{incident.title}</h2>
                  <p className="text-sm text-slate-500">{incident.category}</p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <SeverityBadge severity={incident.severity} />
                  <StatusBadge status={incident.status} />
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
              <h3 className="mb-5 text-lg font-bold">Status timeline</h3>
              <StatusTimeline status={incident.status} />
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-bold">Response team</h3>
              <AssignedTeamCard team={team} incident={incident} />
            </div>
          </div>
        )}
      </div>
    </UserLayout>
  );
}
