import { useCallback, useEffect, useRef, useState } from 'react';
import { CheckCircle2, Copy, Radio } from 'lucide-react';
import UserLayout from '@/components/UserLayout';
import AssignedTeamCard from '@/components/AssignedTeamCard';
import { SeverityBadge, StatusBadge, StatusTimeline } from '@/components/Badges';
import { updateIncidentLocation } from '@/lib/api';
import { Link } from '@/lib/router';
import type { Incident } from '@/lib/types';
import { useLiveLocation, type Coords, type LocationStatus } from '@/lib/useLiveLocation';
import { useReport } from '@/lib/useReport';

export default function LiveReportPage({ reportId }: { reportId: string }) {
  const live = useLiveLocation(true);
  const coordsRef = useRef<Coords | null>(live.coords);
  const [savedAt, setSavedAt] = useState<number | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    coordsRef.current = live.coords;
  });

  const saveLocation = useCallback(async (incident: Incident) => {
    const coords = coordsRef.current;
    if (!coords) return;
    await updateIncidentLocation(incident.id, coords.lat, coords.lng);
    setSavedAt(Date.now());
  }, []);

  const { incident, team, notFound, error, loading } = useReport(reportId, saveLocation);

  const copyId = async () => {
    await navigator.clipboard?.writeText(reportId);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2000);
  };

  return (
    <UserLayout>
      <div className="mx-auto max-w-2xl space-y-6 px-4 py-8 sm:px-6 sm:py-10">
        {notFound && (
          <div className="rounded-2xl border border-slate-200 p-8 text-center">
            <p className="text-lg font-bold">No report found for {reportId}</p>
            <p className="mt-2 text-slate-600">Check the ID and try again.</p>
            <Link to="/track" className="mt-5 inline-block rounded-xl bg-red-600 px-5 py-3 font-semibold text-white hover:bg-red-700">
              Track a report
            </Link>
          </div>
        )}
        {!notFound && !incident && (
          <p className="py-16 text-center text-slate-600">{error ?? 'Loading your report...'}</p>
        )}
        {incident && (
          <>
            <div className="rounded-3xl bg-red-600 p-6 text-white shadow-xl shadow-red-600/20 sm:p-8">
              <div className="flex items-center gap-3 text-red-100">
                <CheckCircle2 size={24} />
                <span className="font-semibold">Emergency report received</span>
              </div>
              <p className="mt-5 text-sm font-medium uppercase tracking-widest text-red-100">Your Report ID</p>
              <div className="mt-1 flex flex-wrap items-center gap-3">
                <p className="font-mono text-4xl font-black tracking-widest sm:text-5xl">{reportId}</p>
                <button
                  type="button"
                  onClick={copyId}
                  className="flex items-center gap-2 rounded-xl bg-white/15 px-3 py-2 text-sm font-semibold transition hover:bg-white/25"
                >
                  <Copy size={16} /> {copied ? 'Copied' : 'Copy'}
                </button>
              </div>
            </div>

            <div className="rounded-2xl border-2 border-red-200 bg-red-50 p-5">
              <p className="text-xl font-extrabold text-red-700">Keep this page open</p>
              <p className="mt-1 text-slate-700">Your live location is saved every 5 seconds while this page stays open.</p>
              <LiveStatusLine status={live.status} savedAt={savedAt} />
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm text-slate-500">{incident.category}</p>
                  <h1 className="text-xl font-bold break-words">{incident.title}</h1>
                  {incident.address && <p className="mt-1 text-sm text-slate-600">{incident.address}</p>}
                </div>
                <div className="flex flex-wrap gap-2">
                  <SeverityBadge severity={incident.severity} />
                  <StatusBadge status={incident.status} />
                </div>
              </div>
              <p className="mt-3 text-sm text-slate-600">
                People affected: <span className="font-bold text-slate-900">{incident.people_affected}</span>
              </p>
            </div>

            <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
              <h2 className="mb-5 text-lg font-bold">Report status</h2>
              <StatusTimeline status={incident.status} />
            </div>

            <AssignedTeamCard team={team} incident={incident} />
          </>
        )}
      </div>
    </UserLayout>
  );
}

function LiveStatusLine({ status, savedAt }: { status: LocationStatus; savedAt: number | null }) {
  if (status === 'live') {
    const time = savedAt ? new Date(savedAt).toLocaleTimeString() : 'just now';
    return (
      <p className="mt-3 flex items-center gap-2 text-sm font-semibold text-emerald-700">
        <Radio size={16} className="animate-pulse" /> Live location on. Last saved {time}.
      </p>
    );
  }
  if (status === 'locating') {
    return <p className="mt-3 text-sm font-semibold text-slate-600">Finding your location...</p>;
  }
  return (
    <p className="mt-3 text-sm font-semibold text-slate-600">
      Live location is off. The location you submitted is kept.
    </p>
  );
}
