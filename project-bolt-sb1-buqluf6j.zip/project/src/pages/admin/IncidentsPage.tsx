import { useState } from 'react';
import { SeverityBadge, StatusBadge } from '@/components/Badges';
import { navigate } from '@/lib/router';
import { formatElapsed } from '@/lib/logic';
import { STATUSES, type Status } from '@/lib/types';
import { useLiveData } from '@/lib/useLiveData';

export default function IncidentsPage() {
  const { incidents, teams, loading, error, now } = useLiveData();
  const [statusFilter, setStatusFilter] = useState<Status | 'All'>('All');

  const rows = incidents.filter((i) => statusFilter === 'All' || i.status === statusFilter);
  const teamName = (id: string | null) => teams.find((t) => t.id === id)?.name ?? '-';

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Incident Management</h1>
          <p className="mt-1 text-sm text-slate-400">Open an incident to update its status, change severity, or assign a team.</p>
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value as Status | 'All')}
          aria-label="Filter by status"
          className="rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-slate-100 outline-none focus:border-red-500"
        >
          <option value="All">All statuses</option>
          {STATUSES.map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
      </header>

      {error && <p className="rounded-xl border border-red-900 bg-red-950/40 p-4 text-sm text-red-300">{error}</p>}

      <section className="overflow-hidden rounded-2xl border border-slate-800 bg-slate-900">
        {loading && incidents.length === 0 ? (
          <p className="p-8 text-center text-slate-400">Loading incidents...</p>
        ) : rows.length === 0 ? (
          <p className="p-8 text-center text-slate-400">No incidents found.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[860px] text-left text-sm">
              <thead className="bg-slate-950/60 text-xs uppercase tracking-wide text-slate-400">
                <tr>
                  <th className="px-4 py-3 font-semibold">Report ID</th>
                  <th className="px-4 py-3 font-semibold">Title</th>
                  <th className="px-4 py-3 font-semibold">Category</th>
                  <th className="px-4 py-3 font-semibold">Severity</th>
                  <th className="px-4 py-3 font-semibold">Status</th>
                  <th className="px-4 py-3 font-semibold">Assigned Team</th>
                  <th className="px-4 py-3 font-semibold">Reported</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {rows.map((incident) => (
                  <tr
                    key={incident.id}
                    onClick={() => navigate(`/admin/incidents/${incident.id}`)}
                    className="cursor-pointer transition hover:bg-slate-800/60"
                  >
                    <td className="px-4 py-4 font-mono text-xs text-slate-400">{incident.report_id}</td>
                    <td className="px-4 py-4 font-semibold text-slate-100">{incident.title}</td>
                    <td className="px-4 py-4 text-slate-300">{incident.category}</td>
                    <td className="px-4 py-4"><SeverityBadge severity={incident.severity} /></td>
                    <td className="px-4 py-4"><StatusBadge status={incident.status} /></td>
                    <td className="px-4 py-4 text-slate-300">{teamName(incident.assigned_team_id)}</td>
                    <td className="px-4 py-4 whitespace-nowrap text-slate-400">{formatElapsed(incident.created_at, now)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
