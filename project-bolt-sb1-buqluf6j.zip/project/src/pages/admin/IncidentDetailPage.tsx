import { useState } from 'react';
import { ArrowLeft, Route, Trash2, Wand2 } from 'lucide-react';
import MapView, { type MapMarker } from '@/components/MapView';
import { AvailabilityBadge, PriorityBadge, SeverityBadge, StatusBadge, StatusTimeline } from '@/components/Badges';
import { assignTeam, deleteIncident, resolveIncident, setIncidentSeverity, setIncidentStatus } from '@/lib/api';
import { etaMinutes, formatElapsed, haversineKm, priorityLevel, priorityScore, suitableTeamCategory } from '@/lib/logic';
import { Link, navigate } from '@/lib/router';
import { SEVERITIES, STATUSES, type Incident, type Severity, type Status, type Team } from '@/lib/types';
import { useLiveData } from '@/lib/useLiveData';

interface Candidate {
  team: Team;
  distance: number | null;
}

export default function IncidentDetailPage({ incidentId }: { incidentId: string }) {
  const { incidents, teams, loading, error: loadError, now, reload } = useLiveData();
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  const incident = incidents.find((i) => i.id === incidentId);
  if (!incident) {
    return (
      <div className="rounded-2xl border border-slate-800 bg-slate-900 p-8 text-center">
        <p className="text-lg font-semibold">{loading ? 'Loading incident...' : 'Incident not found'}</p>
        {loadError && <p className="mt-2 text-sm text-red-400">{loadError}</p>}
        <Link to="/admin/incidents" className="mt-4 inline-block text-sm font-semibold text-red-400 hover:underline">
          Back to incident list
        </Link>
      </div>
    );
  }

  const assignedTeam = teams.find((t) => t.id === incident.assigned_team_id) ?? null;
  const hasCoords = incident.latitude !== null && incident.longitude !== null;
  const distanceTo = (team: Team) =>
    hasCoords ? haversineKm(team.latitude, team.longitude, incident.latitude as number, incident.longitude as number) : null;

  const candidates: Candidate[] = teams
    .filter((t) => t.category === suitableTeamCategory(incident.category))
    .map((team) => ({ team, distance: distanceTo(team) }))
    .sort((a, b) => Number(b.team.availability === 'Available') - Number(a.team.availability === 'Available') || (a.distance ?? 0) - (b.distance ?? 0));

  const bestAvailable = candidates.find((c) => c.team.availability === 'Available');
  const assignedDistance = assignedTeam ? distanceTo(assignedTeam) : null;

  const run = async (action: () => Promise<void>) => {
    setBusy(true);
    setActionError(null);
    try {
      await action();
      reload();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'That change could not be saved.');
    } finally {
      setBusy(false);
    }
  };

  const changeStatus = (status: Status) =>
    run(() => (status === 'Resolved' ? resolveIncident(incident) : setIncidentStatus(incident.id, status)));

  const changeSeverity = (severity: Severity) => run(() => setIncidentSeverity(incident.id, severity));

  const assign = (team: Team) => run(() => assignTeam(incident, team));

  const remove = async () => {
    if (!window.confirm(`Delete incident ${incident.report_id}? This cannot be undone.`)) return;
    setBusy(true);
    try {
      await deleteIncident(incident);
      navigate('/admin/incidents');
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'The incident could not be deleted.');
      setBusy(false);
    }
  };

  const markers: MapMarker[] = [
    ...(hasCoords
      ? [{ id: incident.id, lat: incident.latitude as number, lng: incident.longitude as number, color: '#dc2626', label: `${incident.report_id} · ${incident.title}` }]
      : []),
    ...teams.map((t) => ({
      id: t.id,
      lat: t.latitude,
      lng: t.longitude,
      color: t.availability === 'Available' ? '#2563eb' : '#64748b',
      label: `${t.name} (${t.availability})`,
      square: true,
    })),
  ];
  const route: [number, number][] | undefined =
    hasCoords && assignedTeam
      ? [
          [incident.latitude as number, incident.longitude as number],
          [assignedTeam.latitude, assignedTeam.longitude],
        ]
      : undefined;

  const score = priorityScore(incident, now);

  return (
    <div className="space-y-6">
      <Link to="/admin/incidents" className="inline-flex items-center gap-2 text-sm font-semibold text-slate-400 hover:text-slate-100">
        <ArrowLeft size={16} /> Back to incidents
      </Link>

      <header className="flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0">
          <p className="font-mono text-sm font-bold tracking-widest text-red-400">{incident.report_id}</p>
          <h1 className="text-2xl font-bold tracking-tight break-words">{incident.title}</h1>
          <p className="mt-1 text-sm text-slate-400">
            {incident.category} · {incident.people_affected} people · reported {formatElapsed(incident.created_at, now)}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <SeverityBadge severity={incident.severity} />
          <PriorityBadge level={priorityLevel(score)} />
          <StatusBadge status={incident.status} />
        </div>
      </header>

      {actionError && <p className="rounded-xl border border-red-900 bg-red-950/40 p-3 text-sm text-red-300">{actionError}</p>}

      <div className="grid gap-6 xl:grid-cols-5">
        <div className="space-y-6 xl:col-span-2">
          <section className="rounded-2xl border border-slate-800 bg-slate-900 p-5 space-y-4">
            <h2 className="font-bold">Incident controls</h2>
            <label className="block space-y-1.5">
              <span className="text-sm text-slate-400">Status</span>
              <select
                value={incident.status}
                disabled={busy}
                onChange={(e) => changeStatus(e.target.value as Status)}
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-slate-100 outline-none focus:border-red-500 disabled:opacity-60"
              >
                {STATUSES.map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </label>
            <label className="block space-y-1.5">
              <span className="text-sm text-slate-400">Severity</span>
              <select
                value={incident.severity}
                disabled={busy}
                onChange={(e) => changeSeverity(e.target.value as Severity)}
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-2.5 text-slate-100 outline-none focus:border-red-500 disabled:opacity-60"
              >
                {SEVERITIES.map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </label>
            {incident.description && <p className="rounded-xl bg-slate-950 p-3 text-sm text-slate-300">{incident.description}</p>}
            <div className="text-sm text-slate-400 space-y-1">
              <p>Address: <span className="text-slate-200">{incident.address ?? 'Not given'}</span></p>
              <p>Contact: <span className="text-slate-200">{incident.contact ?? 'Not given'}</span></p>
              <p>Coordinates: <span className="font-mono text-slate-200">{hasCoords ? `${incident.latitude?.toFixed(4)}, ${incident.longitude?.toFixed(4)}` : 'Not shared'}</span></p>
            </div>
            <button
              type="button"
              disabled={busy}
              onClick={remove}
              className="flex w-full items-center justify-center gap-2 rounded-xl border border-red-900 px-4 py-2.5 text-sm font-semibold text-red-400 transition hover:bg-red-950 disabled:opacity-50"
            >
              <Trash2 size={16} /> Delete test or duplicate report
            </button>
          </section>

          <section className="rounded-2xl border border-slate-800 bg-slate-900 p-5">
            <h2 className="mb-4 font-bold">Status timeline</h2>
            <StatusTimeline status={incident.status} />
          </section>
        </div>

        <div className="space-y-6 xl:col-span-3">
          <section className="rounded-2xl border border-slate-800 bg-slate-900 p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="font-bold">Team assignment</h2>
              <button
                type="button"
                disabled={busy || !bestAvailable || incident.status === 'Resolved'}
                onClick={() => bestAvailable && assign(bestAvailable.team)}
                className="flex items-center gap-2 rounded-xl bg-red-600 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-red-500 disabled:cursor-not-allowed disabled:opacity-40"
              >
                <Wand2 size={16} /> Auto-assign nearest available team
              </button>
            </div>
            {!bestAvailable && incident.status !== 'Resolved' && (
              <p className="text-sm text-amber-300">No available {suitableTeamCategory(incident.category)} team right now. Pick a team manually when one is free.</p>
            )}

            {assignedTeam && (
              <div className="rounded-xl border border-sky-500/40 bg-sky-500/10 p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="font-bold text-slate-100">{assignedTeam.name}</p>
                  <AvailabilityBadge availability={assignedTeam.availability} />
                </div>
                <p className="text-sm text-slate-400">{assignedTeam.team_code} · {assignedTeam.category} response</p>
                {assignedDistance !== null && (
                  <div className="mt-3 grid grid-cols-2 gap-3">
                    <div className="rounded-lg bg-slate-950/60 p-3">
                      <p className="text-xs uppercase tracking-wide text-slate-500">Distance</p>
                      <p className="text-lg font-bold">{assignedDistance.toFixed(2)} km</p>
                    </div>
                    <div className="rounded-lg bg-slate-950/60 p-3">
                      <p className="text-xs uppercase tracking-wide text-slate-500">ETA at 40 km/h</p>
                      <p className="text-lg font-bold">{etaMinutes(assignedDistance)} min</p>
                    </div>
                  </div>
                )}
              </div>
            )}

            <div>
              <p className="mb-2 text-sm font-semibold text-slate-400">
                Candidate {suitableTeamCategory(incident.category)} teams, nearest first
              </p>
              {candidates.length === 0 ? (
                <p className="text-sm text-slate-500">No teams are set up for this category.</p>
              ) : (
                <ul className="divide-y divide-slate-800 rounded-xl border border-slate-800">
                  {candidates.map(({ team, distance }) => {
                    const isAssigned = team.id === incident.assigned_team_id;
                    const canAssign = !busy && incident.status !== 'Resolved' && team.availability === 'Available';
                    return (
                      <li key={team.id} className="flex flex-wrap items-center justify-between gap-3 p-3">
                        <div>
                          <p className="font-semibold text-slate-100">{team.name}</p>
                          <p className="text-xs text-slate-500">
                            {team.team_code} · {distance !== null ? `${distance.toFixed(2)} km away` : 'distance unknown'}
                          </p>
                        </div>
                        <div className="flex items-center gap-3">
                          <AvailabilityBadge availability={team.availability} />
                          <button
                            type="button"
                            disabled={!canAssign}
                            onClick={() => assign(team)}
                            className="rounded-lg bg-slate-100 px-3 py-1.5 text-sm font-semibold text-slate-900 transition hover:bg-white disabled:cursor-not-allowed disabled:opacity-40"
                          >
                            {isAssigned ? 'Assigned' : 'Assign'}
                          </button>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </section>

          <section className="rounded-2xl border border-slate-800 bg-slate-900 p-5">
            <div className="mb-3 flex items-center justify-between gap-3">
              <h2 className="flex items-center gap-2 font-bold"><Route size={18} /> Live map</h2>
              <p className="text-xs text-slate-500">Reloads every 3 seconds</p>
            </div>
            <MapView markers={markers} route={route} className="h-96" />
          </section>
        </div>
      </div>
    </div>
  );
}
