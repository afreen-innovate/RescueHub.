import { useState } from 'react';
import { Pencil, Plus, Trash2 } from 'lucide-react';
import { AvailabilityBadge } from '@/components/Badges';
import TeamForm from '@/components/TeamForm';
import { deleteTeam } from '@/lib/api';
import { useLiveData } from '@/lib/useLiveData';
import type { Team } from '@/lib/types';

export default function TeamsPage() {
  const { incidents, teams, loading, error: loadError, reload } = useLiveData();
  const [editing, setEditing] = useState<Team | 'new' | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  const incidentLabel = (id: string | null) => {
    const incident = incidents.find((i) => i.id === id);
    return incident ? `${incident.report_id} · ${incident.title}` : 'None';
  };

  const remove = async (team: Team) => {
    if (!window.confirm(`Delete ${team.name}? Any assigned incident will go back to Pending.`)) return;
    try {
      await deleteTeam(team, incidents);
      reload();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'The team could not be deleted.');
    }
  };

  const closeForm = () => setEditing(null);
  const saved = () => {
    setEditing(null);
    reload();
  };

  return (
    <div className="space-y-6">
      <header className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Response Team Management</h1>
          <p className="mt-1 text-sm text-slate-400">Create and edit teams, set their location, availability, and assigned incident.</p>
        </div>
        <button
          type="button"
          onClick={() => setEditing('new')}
          className="flex items-center gap-2 rounded-xl bg-red-600 px-4 py-2.5 text-sm font-bold text-white transition hover:bg-red-500"
        >
          <Plus size={18} /> Add Team
        </button>
      </header>

      {(actionError || loadError) && (
        <p className="rounded-xl border border-red-900 bg-red-950/40 p-4 text-sm text-red-300">{actionError ?? loadError}</p>
      )}

      <section className="overflow-hidden rounded-2xl border border-slate-800 bg-slate-900">
        {loading && teams.length === 0 ? (
          <p className="p-8 text-center text-slate-400">Loading teams...</p>
        ) : teams.length === 0 ? (
          <p className="p-8 text-center text-slate-400">No teams yet. Add the first response team.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[820px] text-left text-sm">
              <thead className="bg-slate-950/60 text-xs uppercase tracking-wide text-slate-400">
                <tr>
                  <th className="px-4 py-3 font-semibold">Team</th>
                  <th className="px-4 py-3 font-semibold">Category</th>
                  <th className="px-4 py-3 font-semibold">Availability</th>
                  <th className="px-4 py-3 font-semibold">Assigned Incident</th>
                  <th className="px-4 py-3 font-semibold">Location</th>
                  <th className="px-4 py-3 text-right font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {teams.map((team) => (
                  <tr key={team.id} className="transition hover:bg-slate-800/50">
                    <td className="px-4 py-4">
                      <p className="font-semibold text-slate-100">{team.name}</p>
                      <p className="font-mono text-xs text-slate-500">{team.team_code}</p>
                    </td>
                    <td className="px-4 py-4 text-slate-300">{team.category}</td>
                    <td className="px-4 py-4"><AvailabilityBadge availability={team.availability} /></td>
                    <td className="px-4 py-4 text-slate-300">{incidentLabel(team.assigned_incident_id)}</td>
                    <td className="px-4 py-4 font-mono text-xs text-slate-400">{team.latitude.toFixed(4)}, {team.longitude.toFixed(4)}</td>
                    <td className="px-4 py-4">
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setEditing(team)}
                          aria-label={`Edit ${team.name}`}
                          className="rounded-lg p-2 text-slate-300 transition hover:bg-slate-800 hover:text-white"
                        >
                          <Pencil size={16} />
                        </button>
                        <button
                          type="button"
                          onClick={() => remove(team)}
                          aria-label={`Delete ${team.name}`}
                          className="rounded-lg p-2 text-red-400 transition hover:bg-red-950 hover:text-red-300"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {editing && (
        <TeamForm
          team={editing === 'new' ? null : editing}
          incidents={incidents}
          onClose={closeForm}
          onSaved={saved}
        />
      )}
    </div>
  );
}
