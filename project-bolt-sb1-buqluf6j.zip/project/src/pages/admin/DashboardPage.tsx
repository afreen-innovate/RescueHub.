import { useMemo, useState } from 'react';
import { AlertTriangle, CheckCircle2, Clock, Siren, Truck, Users, Zap, type LucideIcon } from 'lucide-react';
import MapView, { type MapMarker } from '@/components/MapView';
import { PriorityBadge, SeverityBadge, StatusBadge } from '@/components/Badges';
import { formatElapsed, isOpen, priorityLevel, priorityScore } from '@/lib/logic';
import { navigate } from '@/lib/router';
import { CATEGORIES, STATUSES, type Category, type Incident, type Status } from '@/lib/types';
import { useLiveData } from '@/lib/useLiveData';

const LIVE_WINDOW_MS = 30_000;

const SEVERITY_COLORS: Record<Incident['severity'], string> = {
  Critical: '#dc2626',
  High: '#f97316',
  Medium: '#f59e0b',
  Low: '#10b981',
};

interface RankedIncident {
  incident: Incident;
  score: number;
  rank: number | null;
}

export default function DashboardPage() {
  const { incidents, teams, loading, error, now } = useLiveData();
  const [statusFilter, setStatusFilter] = useState<Status | 'All'>('All');
  const [categoryFilter, setCategoryFilter] = useState<Category | 'All'>('All');

  const stats = useMemo(
    () => ({
      total: incidents.length,
      critical: incidents.filter((i) => i.severity === 'Critical').length,
      pending: incidents.filter((i) => i.status === 'Reported' || i.status === 'Pending').length,
      assigned: incidents.filter((i) => i.status === 'Assigned').length,
      resolved: incidents.filter((i) => i.status === 'Resolved').length,
      available: teams.filter((t) => t.availability === 'Available').length,
      busy: teams.filter((t) => t.availability === 'Busy').length,
    }),
    [incidents, teams],
  );

  const categoryCounts = useMemo(
    () => CATEGORIES.map((category) => ({ category, count: incidents.filter((i) => i.category === category).length })),
    [incidents],
  );
  const maxCategoryCount = Math.max(1, ...categoryCounts.map((c) => c.count));

  const ranked = useMemo<RankedIncident[]>(() => {
    const scored = incidents.map((incident) => ({ incident, score: priorityScore(incident, now) }));
    const open = scored.filter((s) => isOpen(s.incident)).sort((a, b) => b.score - a.score);
    const closed = scored.filter((s) => !isOpen(s.incident)).sort((a, b) => b.score - a.score);
    return [
      ...open.map((s, index) => ({ ...s, rank: index + 1 })),
      ...closed.map((s) => ({ ...s, rank: null })),
    ];
  }, [incidents, now]);

  const rows = ranked.filter(
    (row) =>
      (statusFilter === 'All' || row.incident.status === statusFilter) &&
      (categoryFilter === 'All' || row.incident.category === categoryFilter),
  );

  const markers = useMemo<MapMarker[]>(() => {
    const incidentMarkers = incidents
      .filter((i) => i.latitude !== null && i.longitude !== null)
      .map((i) => ({
        id: i.id,
        lat: i.latitude as number,
        lng: i.longitude as number,
        color: SEVERITY_COLORS[i.severity],
        label: `${i.report_id} · ${i.title} (${i.severity})`,
      }));
    const teamMarkers = teams.map((t) => ({
      id: t.id,
      lat: t.latitude,
      lng: t.longitude,
      color: t.availability === 'Available' ? '#2563eb' : '#64748b',
      label: `${t.name} (${t.category}, ${t.availability})`,
      square: true,
    }));
    return [...incidentMarkers, ...teamMarkers];
  }, [incidents, teams]);

  if (error && incidents.length === 0) {
    return <div className="rounded-2xl border border-red-900 bg-red-950/40 p-6 text-red-300">Could not load dashboard data: {error}</div>;
  }

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-2xl font-bold tracking-tight">Emergency Dashboard</h1>
        <p className="mt-1 text-sm text-slate-400">Live view of incidents and response teams. Refreshes every 3 seconds.</p>
      </header>

      <section className="grid grid-cols-2 gap-4 xl:grid-cols-4">
        <StatCard label="Total Reported Incidents" value={stats.total} icon={Siren} tone="slate" />
        <StatCard label="Critical Incidents" value={stats.critical} icon={AlertTriangle} tone="red" glow={stats.critical > 0} />
        <StatCard label="Pending Incidents" value={stats.pending} icon={Clock} tone="amber" />
        <StatCard label="Assigned Incidents" value={stats.assigned} icon={Zap} tone="sky" />
        <StatCard label="Resolved Incidents" value={stats.resolved} icon={CheckCircle2} tone="emerald" />
        <StatCard label="Available Response Teams" value={stats.available} icon={Users} tone="emerald" />
        <StatCard label="Busy Response Teams" value={stats.busy} icon={Truck} tone="slate" />
      </section>

      <div className="grid gap-6 xl:grid-cols-3">
        <section className="rounded-2xl border border-slate-800 bg-slate-900 p-5 xl:col-span-1">
          <h2 className="font-bold">Incident Distribution by Category</h2>
          <p className="mb-5 text-sm text-slate-400">Number of incidents reported per category</p>
          <div className="space-y-4">
            {categoryCounts.map(({ category, count }) => (
              <div key={category}>
                <div className="mb-1.5 flex justify-between text-sm">
                  <span className="text-slate-300">{category}</span>
                  <span className="font-semibold text-slate-100">{count}</span>
                </div>
                <div className="h-2.5 overflow-hidden rounded-full bg-slate-800">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-red-700 to-red-500 transition-all duration-700"
                    style={{ width: `${(count / maxCategoryCount) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="rounded-2xl border border-slate-800 bg-slate-900 p-5 xl:col-span-2">
          <h2 className="mb-1 font-bold">Incident and Team Map</h2>
          <p className="mb-4 text-sm text-slate-400">
            Circles are incidents colored by severity. Squares are response teams (blue available, grey busy).
          </p>
          <MapView markers={markers} className="h-[22rem]" />
        </section>
      </div>

      <section className="rounded-2xl border border-slate-800 bg-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 p-5">
          <div>
            <h2 className="font-bold">Ranked Incident Priority</h2>
            <p className="text-sm text-slate-400">Open incidents ranked highest priority first. Click a row to manage it.</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as Status | 'All')}
              aria-label="Filter by status"
              className="rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-slate-100 outline-none focus:border-red-500"
            >
              <option value="All">All statuses</option>
              {STATUSES.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value as Category | 'All')}
              aria-label="Filter by category"
              className="rounded-xl border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-slate-100 outline-none focus:border-red-500"
            >
              <option value="All">All categories</option>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
        </div>

        {loading && incidents.length === 0 ? (
          <p className="p-8 text-center text-slate-400">Loading incidents...</p>
        ) : rows.length === 0 ? (
          <p className="p-8 text-center text-slate-400">No incidents match these filters.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[960px] text-left text-sm">
              <thead className="bg-slate-950/60 text-xs uppercase tracking-wide text-slate-400">
                <tr>
                  <th className="px-4 py-3 font-semibold">Rank</th>
                  <th className="px-4 py-3 font-semibold">Incident</th>
                  <th className="px-4 py-3 font-semibold">Category</th>
                  <th className="px-4 py-3 font-semibold">People</th>
                  <th className="px-4 py-3 font-semibold">Severity</th>
                  <th className="px-4 py-3 font-semibold">Priority</th>
                  <th className="px-4 py-3 font-semibold">Status</th>
                  <th className="px-4 py-3 font-semibold">Reported</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {rows.map(({ incident, score, rank }) => {
                  const critical = incident.severity === 'Critical' && isOpen(incident);
                  const live = incident.location_updated_at !== null && now - new Date(incident.location_updated_at).getTime() < LIVE_WINDOW_MS;
                  return (
                    <tr
                      key={incident.id}
                      onClick={() => navigate(`/admin/incidents/${incident.id}`)}
                      className={`cursor-pointer transition hover:bg-slate-800/60 ${critical ? 'bg-red-500/10' : ''}`}
                    >
                      <td className={`px-4 py-4 font-bold ${critical ? 'shadow-[inset_4px_0_0_0_#ef4444] text-red-300' : 'text-slate-300'}`}>
                        {rank ?? '-'}
                      </td>
                      <td className="px-4 py-4">
                        <p className="font-semibold text-slate-100">{incident.title}</p>
                        <p className="mt-0.5 flex items-center gap-2 font-mono text-xs text-slate-500">
                          {incident.report_id}
                          {live && (
                            <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/20 px-2 py-0.5 font-sans font-bold text-emerald-300 ring-1 ring-emerald-500/40">
                              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" /> LIVE
                            </span>
                          )}
                        </p>
                      </td>
                      <td className="px-4 py-4 text-slate-300">{incident.category}</td>
                      <td className="px-4 py-4 text-slate-300">{incident.people_affected}</td>
                      <td className="px-4 py-4">
                        <span className={critical ? 'rounded-full shadow-[0_0_18px_rgba(239,68,68,0.7)]' : ''}>
                          <SeverityBadge severity={incident.severity} />
                        </span>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-2">
                          <PriorityBadge level={priorityLevel(score)} />
                          <span className="font-mono text-xs text-slate-400">{score.toFixed(1)}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4"><StatusBadge status={incident.status} /></td>
                      <td className="px-4 py-4 whitespace-nowrap text-slate-400">{formatElapsed(incident.created_at, now)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}

const TONES: Record<string, string> = {
  slate: 'text-slate-300 bg-slate-800',
  red: 'text-red-400 bg-red-500/15',
  amber: 'text-amber-300 bg-amber-500/15',
  sky: 'text-sky-300 bg-sky-500/15',
  emerald: 'text-emerald-300 bg-emerald-500/15',
};

function StatCard({ label, value, icon: Icon, tone, glow = false }: { label: string; value: number; icon: LucideIcon; tone: string; glow?: boolean }) {
  return (
    <div className={`rounded-2xl border bg-slate-900 p-5 transition hover:-translate-y-0.5 ${glow ? 'border-red-500/60 shadow-[0_0_28px_rgba(239,68,68,0.35)]' : 'border-slate-800'}`}>
      <div className="flex items-start justify-between gap-3">
        <p className="text-sm font-medium text-slate-400">{label}</p>
        <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${TONES[tone]}`}>
          <Icon size={18} />
        </span>
      </div>
      <p className="mt-3 text-3xl font-extrabold tabular-nums text-slate-50">{value}</p>
    </div>
  );
}
